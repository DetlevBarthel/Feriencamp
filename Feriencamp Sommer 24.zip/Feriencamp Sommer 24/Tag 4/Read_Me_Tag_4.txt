Video Bytes N Bits:
Add a web control panel to your project - the web server
Alles ist auf der Seite bytesnbits.co.uk/web-control-panel-web-serverdon
Dieser hat 3 Elemente
1. http-request-parser
2. request-handler
3. response builder

Nee, ich mache weiter mit Donsky Tech - MQTT
1. Herunterladen von MQTTX
2. Mosquitto Broker auf dem PC installieren und unter Dienste zum Laufen bringen
3. IP-Adresse des Mosquitto-Brokers ist