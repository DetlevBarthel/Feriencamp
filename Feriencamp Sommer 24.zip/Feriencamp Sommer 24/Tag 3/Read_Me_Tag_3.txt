1. Cleanup mit Garbage Collector aus Projekt 5
2. NTP-Aufruf mit Projekt 6
3. Einführen des DHT11, erst als einzelnes Programm, dann als Klasse
4. Benutzen des MOSFET für die Schaltung der GrowLED
5. MQTT starten mit Projekt 7: Zuerst erkläre ich die Seite von io.adafruit.com
	Hier ist das Video:https://www.youtube.com/watch?v=ybCMXqsQyDw
6. Ich benötige den Key und wir legen feeds und Blöcke auf dem Dashboard an




