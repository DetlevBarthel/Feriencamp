# watchdog timer und garbage collector installieren
#WDT Bibliothek installieren
'''
In Ihrem Code sorgt der Block if __name__ == "__main__": dafür, dass die Funktion main()
nur dann aufgerufen wird, wenn das Skript main.py direkt ausgeführt wird, nicht aber, wenn es
von einem anderen Skript importiert wird.
'''

from GrowLed import GrowLed
from WLan import WLan
print("Hallo")
from Http_request import Http 
from Oled import Oled
from time import sleep
from Cleanup import Putzmann
import gc
from machine import WDT

startzeit = (14,35)
endzeit = (14,36)
def main():
    print(0)
    oled = Oled()
    sleep(1)
    light_1 = GrowLed(startZeit = startzeit, endZeit =endzeit)
    print("Starting loop...")
    sleep(1)
    internetVerbindung = WLan()
    sleep(1)
    http_request = Http()
    print(1)
    sleep(2)
    print(2)
    sleep(1)
    putzMann = Putzmann()
    
    while True:
        #light_1.blinkLed()
        stunden, minuten, sekunden = http_request.update_internetTime()
        oled.ssd1306.fill(0)        
        light_1.growLed_schalten(stunden, minuten, sekunden)
        print(3)
        zeit = 'Uhr = ' + str(stunden) + ":"+str(minuten)+":"+str(sekunden)
        oled.display(zeit, x= 0, y = 0)
        start = str(startzeit[0]) + ":" + str(startzeit[1])
        oled.display(start, x= 0, y = 16)
        ende = str(endzeit[0]) + ":" + str(endzeit[1])
        oled.display(ende, x= 0, y = 30)
        free_mem = putzMann.putzen()
        oled.display(free_mem, x=0, y=45)

        sleep(2)
        
if __name__ == "__main__":
    main()