
import time
import urequests
'''
Die Bibliothek urequests ist eine MicroPython-Implementierung der weit verbreiteten requests-Bibliothek
in Python. Sie ermöglicht es, HTTP-Anfragen (wie GET, POST, PUT, DELETE) einfach und effizient durchzuführen,
was besonders nützlich für IoT-Projekte und eingebettete Systeme wie den Raspberry Pi Pico ist, die eine
Netzwerkverbindung nutzen.
'''

class Http:
    def __init__(self):
        self.sekunden = 0
        self.zeit = 0
        self.current_time = 0
    
    def update_internetTime(self):
            #global current_time, startZeit, endZeit
        # Uhrzeit von API abrufen    
        self.response = urequests.get('https://timeapi.io/api/Time/current/zone?timezone=Europe/Berlin')
        #print(response)
        while self.response.status_code != 200:
            self.response = urequests.get('https://timeapi.io/api/Time/current/zone?timezone=Europe/Berlin')
            time.sleep(1)
            print("Fehler beim Abrufen der Uhrzeit:", self.response.status_code)
            self.response.close()
        if self.response.status_code == 200:
            # JSON-Daten von der API abrufen
            self.data = self.response.json()
            # Uhrzeit aus den JSON-Daten extrahieren
            self.sekunden = self.data['seconds']
            self.minuten = self.data['minute']
            self.stunden = self.data['hour']
            #print(f'Sekunden = {self.sekunden}')
        return  self.stunden,self.minuten, self.sekunden
        

