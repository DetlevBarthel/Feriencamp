import network
import time

class Wlan:
    def __init__(self, SSID, PW):
        self.wlan = network.WLAN(network.STA_IF)
        self.wlan.active(True)
        self.wlan.connect(SSID, PW)
        while not self.wlan.isconnected() and self.wlan.status() >= 0:
            print("Verbinde, bitte warten...")
            time.sleep(2)
            self.wlan.active(True)
            self.wlan.connect(SSID, PW)
            
        print("bin online")
          
   
    
 



    
    
  
        

