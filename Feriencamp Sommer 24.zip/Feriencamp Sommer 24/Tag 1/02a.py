"""
Basic multi thread example. Zwei LEDs laufen auf unterschiedlichen Threads
"""
from machine import Pin
from time import sleep
import _thread
led_extern = Pin(15, Pin.OUT)
LED    = machine.Pin("LED",machine.Pin.OUT)

def core2_thread():
    counter2 = 1
    while True:
        LED.value(1)
        sleep(0.1)
        LED.value(0)
        sleep(1)
        print(f'counter2 = {counter2}')
        counter2 += 1
        
second_thread = _thread.start_new_thread(core2_thread, ())
counter1 = 1
while True:
    led_extern.value(1)
    sleep(1)
    led_extern.value(0)
    sleep(1)
    print(counter1)
    print(f'counter1 = {counter1}')
    counter1 += 1
