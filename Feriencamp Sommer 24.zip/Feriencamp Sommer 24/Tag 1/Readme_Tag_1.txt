Beim 1. Tag geht es darum, das Board kennenzulernen
zu sehen, wie es mit seiner Umgebung interagiert
Lektion 01: 10 minuten. Pinout erklären, Onboard-Led
Lektion 02: Led aufstecken plus Widerstand
Lektion 03: Inbetriebnahme des OLED-Displays
Lektion 04: WLan-Verbindung aufbauen