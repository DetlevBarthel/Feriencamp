import machine
import ssd1306
import time

# Initialize I2C communication
i2c = machine.I2C(0, scl=machine.Pin(17), sda=machine.Pin(16))

# Initialize the display
oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)

# Button setup
button_up = machine.Pin(14, machine.Pin.IN, machine.Pin.PULL_UP)
button_down = machine.Pin(15, machine.Pin.IN, machine.Pin.PULL_UP)

# Line properties
line_length = 10
line_x = 0
line_y = 0

def draw_line(oled, x, y, length):
    for i in range(length):
        oled.pixel(x, y + i, 1)

while True:
    # Clear the display
    oled.fill(0)
    
    # Draw the line at the current position
    draw_line(oled, line_x, line_y, line_length)
    
    # Update the display
    oled.show()
    
    # Update the position of the line based on button presses
    if not button_up.value() and line_y > 0:
        line_y -= 1
        time.sleep(0.1)  # Debounce delay
    if not button_down.value() and line_y < oled_height - line_length:
        line_y += 1
        time.sleep(0.1)  # Debounce delay
    
    # Delay to control the speed of the movement
    time.sleep(0.01)
