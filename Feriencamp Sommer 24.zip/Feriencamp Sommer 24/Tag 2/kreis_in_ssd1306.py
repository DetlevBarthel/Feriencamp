import machine
import ssd1306
import time

# Initialize I2C communication
i2c = machine.I2C(0, scl=machine.Pin(17), sda=machine.Pin(16))

# Initialize the display
oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)

# Circle properties
x = 0
y = oled_height // 2
radius = 5
dx = 1

def draw_circle(oled, x, y, radius):
    for i in range(0, 360, 5):
        radians = i * 3.14 / 180
        cx = int(x + radius * machine.sin(radians))
        cy = int(y + radius * machine.cos(radians))
        oled.pixel(cx, cy, 1)

while True:
    # Clear the display
    oled.fill(0)
    
    # Draw the circle at the current position
    draw_circle(oled, x, y, radius)
    
    # Update the display
    oled.show()
    
    # Update the position of the circle
    x += dx
    if x - radius < 0 or x + radius > oled_width:
        dx = -dx
    
    # Delay to control the speed of the movement
    time.sleep(0.05)
