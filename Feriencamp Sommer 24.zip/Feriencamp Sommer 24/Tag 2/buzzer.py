import machine
import utime

# Initialisieren des PWM-Pins
buzzer = machine.Pin(15)
pwm = machine.PWM(buzzer)

def play_tone(frequency, duration, duty):
    """
    Spielt einen Ton mit einer bestimmten Frequenz, Dauer und Lautstärke.
    
    :param frequency: Frequenz des Tons (in Hertz)
    :param duration: Dauer des Tons (in Millisekunden)
    :param duty: Duty Cycle des PWM-Signals (0 bis 1023), um die Lautstärke zu steuern
    """
    pwm.freq(frequency)
    pwm.duty_u16(duty)
    utime.sleep_ms(duration)
    pwm.duty_u16(0)  # Buzzer ausschalten

def main():
    try:
        while True:
            # Beispiel: Spielt einen Ton mit 440 Hz (A4) für 1 Sekunde mit mittlerer Lautstärke
            play_tone(440, 1000, 512)
            utime.sleep(1)  # Pause von 1 Sekunde

            # Beispiel: Spielt einen Ton mit 880 Hz (A5) für 0.5 Sekunden mit hoher Lautstärke
            play_tone(880, 500, 1023)
            utime.sleep(1)  # Pause von 1 Sekunde
            
    except KeyboardInterrupt:
        # Bei KeyboardInterrupt den Buzzer ausschalten
        pwm.deinit()

if __name__ == "__main__":
    main()
