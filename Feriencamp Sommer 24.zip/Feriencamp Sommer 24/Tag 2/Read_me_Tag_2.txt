Wir erstellen die WLAN-Klasse mit Parametern. Das versucht jeder selbst.
Wir holen die Zeitinformation und bringen sie auf das Display
Wir starten eine Ampel zu einer bestimmten Zeit
Wir starten eine LED zu einer bestimmten Zeit
Wir starten die Ampel mit dem Pushbutton
