import network
import socket
import machine
import time

# Verbindung zum WLAN herstellen
ssid = 'DeinSSID'
password = 'DeinPasswort'
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(ssid, password)

while not wlan.isconnected():
    pass

print('Netzwerk konfiguriert:', wlan.ifconfig())

# Knopf und LED-Pin definieren
button = machine.Pin(16, machine.Pin.IN, machine.Pin.PULL_UP)  # Annahme: Knopf ist an GP14
led = machine.Pin('LED', machine.Pin.OUT)

# Server-IP-Adresse und Port (anpassen an dein Setup)
server_ip = '192.168.2.153'
server_port = 80

def send_request(path): # sendet eine GET-Anfrage an den Server, um die LED zu schalten
    addr = socket.getaddrinfo(server_ip, server_port)[0][-1] # letztes Tupel, welches die Adresse enthält
    s = socket.socket() # erstelle ein socket-Objekt
    s.connect(addr)
    request = f"GET {path} HTTP/1.1\r\nHost: {server_ip}\r\n\r\n" #{path} ist der Pfad der Anfrage (z.B. /?led=on oder /?led=off).
    #r\nHost: {server_ip}\r\n\r\n fügt den Host-Header und zwei Leerzeilen hinzu, um das Ende der HTTP-Header anzuzeigen.
    s.send(request.encode())
    #s.send(request.encode()): Sendet die Anfrage an den Server. request.encode() konvertiert die Anfrage in Bytes, die vom Socket gesendet werden können.
    response = s.recv(1024).decode()
    # recv blockiert das Programm, bis eine Antwort angekommen ist
    # die response ist ein Antwortcode
    print(response)
    s.close()

# Hauptschleife, die auf Knopfdruck wartet
led_state = False

while True:
    if not button.value():  # Wenn der Knopf gedrückt wird (Pull-Up, also LOW wenn gedrückt)
        led_state = not led_state
        if led_state:
            send_request('/?led=on')
        else:
            send_request('/?led=off')
        
        # Warte, bis der Knopf losgelassen wird, um Prellen zu vermeiden
        while not button.value():
            time.sleep(0.1)
    
    time.sleep(0.1)  # Kurze Verzögerung, um die CPU zu entlasten
