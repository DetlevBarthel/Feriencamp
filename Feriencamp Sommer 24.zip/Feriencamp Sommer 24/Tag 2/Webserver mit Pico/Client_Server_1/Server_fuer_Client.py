import network
import socket
import machine

# Verbindung zum WLAN herstellen
ssid = 'DeinSSID'
password = 'DeinPasswort'
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(ssid, password)

while not wlan.isconnected():
    pass

print('Netzwerk konfiguriert:', wlan.ifconfig())

# LED-Pin definieren
led = machine.Pin('LED', machine.Pin.OUT)

# Erstellen eines Server-Sockets
addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]
server_socket = socket.socket()
server_socket.bind(addr)
server_socket.listen(1)

print('Server läuft...')

while True:
    # Akzeptieren einer eingehenden Verbindung, es gibt jetzt sockets für verschiedene Klienten
    client_socket, client_addr = server_socket.accept()
    print('Verbindung von', client_addr)
    
    request = client_socket.recv(1024)
    request = str(request)
    print('Anfrage:', request)
    
    # Überprüfen der Anforderung und Steuern der LED
    if '/?led=on' in request:
        led.on()
        response = 'LED ist jetzt AN'
    elif '/?led=off' in request:
        led.off()
        response = 'LED ist jetzt AUS'
    else:
        response = 'Ungültige Anfrage'

    # Senden der Antwort an den Client
    client_socket.send(response)
    
    # Schließen der Verbindung
    client_socket.close()
