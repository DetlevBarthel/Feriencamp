import network
import socket
import machine

# Verbindung zum WLAN herstellen
ssid = 'DeinSSID'
password = 'DeinPasswort'
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(ssid, password)

while not wlan.isconnected():
    pass

print('Netzwerk konfiguriert:', wlan.ifconfig())

# LED-Pins definieren
led1 = machine.Pin(15, machine.Pin.OUT)
led2 = machine.Pin(16, machine.Pin.OUT)

# Erstellen eines Server-Sockets
addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]
server_socket = socket.socket()
server_socket.bind(addr)
server_socket.listen(1)

print('Server läuft...')

while True:
    # Akzeptieren einer eingehenden Verbindung
    client_socket, client_addr = server_socket.accept()
    print('Verbindung von', client_addr)
    
    request = client_socket.recv(1024)
    request = str(request)
    print('Anfrage:', request)
    
    # Überprüfen der Anforderung und Steuern der LEDs
    if '/?led1=on' in request:
        led1.on()
        response = 'LED 1 ist jetzt AN'
    elif '/?led1=off' in request:
        led1.off()
        response = 'LED 1 ist jetzt AUS'
    elif '/?led2=on' in request:
        led2.on()
        response = 'LED 2 ist jetzt AN'
    elif '/?led2=off' in request:
        led2.off()
        response = 'LED 2 ist jetzt AUS'
    else:
        response = 'Ungültige Anfrage'

    # Senden der Antwort an den Client
    client_socket.send(response.encode())
    
    # Schließen der Verbindung
    client_socket.close()
