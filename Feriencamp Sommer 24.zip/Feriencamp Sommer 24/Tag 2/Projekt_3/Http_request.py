
import time
import urequests
'''
Die Bibliothek urequests ist eine MicroPython-Implementierung der weit verbreiteten requests-Bibliothek
in Python. Sie ermöglicht es, HTTP-Anfragen (wie GET, POST, PUT, DELETE) einfach und effizient durchzuführen,
was besonders nützlich für IoT-Projekte und eingebettete Systeme wie den Raspberry Pi Pico ist, die eine
Netzwerkverbindung nutzen.
'''

class Http:
    def __init__(self):
        self.zeit = 0
    
    def update_internetTime(self):
            #global current_time, startZeit, endZeit
        # Uhrzeit von API abrufen    
        response = urequests.get('https://timeapi.io/api/Time/current/zone?timezone=Europe/Berlin')
        while response.status_code != 200:
            response = urequests.get('https://timeapi.io/api/Time/current/zone?timezone=Europe/Berlin')
            time.sleep(1)
            print("Fehler beim Abrufen der Uhrzeit:", response.status_code)
            response.close()
        if response.status_code == 200:
            # JSON-Daten von der API abrufen
            data = response.json()
            # Uhrzeit aus den JSON-Daten extrahieren
            current_time = data['time']
            sekunden = str(round(data['seconds'],1))
            self.zeit = current_time+":"+sekunden

