# Die main.py bootet beim Start des Pico automatisch
# Nach der LED starten wir das WLAN
# Jetzt machen wir die http-Request
'''
In Ihrem Code sorgt der Block if __name__ == "__main__": dafür, dass die Funktion main()
nur dann aufgerufen wird, wenn das Skript main.py direkt ausgeführt wird, nicht aber, wenn es
von einem anderen Skript importiert wird.
'''

from GrowLed import GrowLed
from WLan import WLan
from Http_request import Http


def main():
    light_1 = GrowLed()
    print("Starting loop...")
    internetVerbindung = WLan()
    http_request = Http()
    while True:
        light_1.blinkLed()
        http_request.update_internetTime()
        print(http_request.zeit)
        
if __name__ == "__main__":
    main()